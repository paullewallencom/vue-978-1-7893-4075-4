<template>
  <div>
    <search />
  </div>
</template>

<script>
import ShowSearch from '@/components/ShowSearch'

export default {
  components: {
    'search': ShowSearch
  }
}
</script>

<style>
</style>
